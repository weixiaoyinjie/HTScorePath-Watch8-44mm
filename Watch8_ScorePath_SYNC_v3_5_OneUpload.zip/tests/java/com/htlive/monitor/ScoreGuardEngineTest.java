package com.htlive.monitor;
import org.json.JSONArray;
import org.json.JSONObject;
public final class ScoreGuardEngineTest {
 static int n=0;
 static void expect(boolean v,String message){if(!v)throw new AssertionError(message);n++;}
 static JSONObject b(String target){return new JSONObject().put("role","主单").put("pick",target).put("closed",false);}
 static JSONObject live(int h,int a,long now){return new JSONObject().put("h",h).put("a",a).put("minute",30).put("status","1H").put("lastStatsAt",now);}
 static JSONObject side(int shots,int on,int box,double xg){return new JSONObject().put("shots",shots).put("on",on).put("box",box).put("xg",xg);}
 static JSONObject matches(int h,int a,JSONArray bets,long now)throws Exception{return ScoreGuardEngine.analyze(live(h,a,now),bets,now);}
 public static void main(String[] args)throws Exception{
  long t=1000000L;
  expect("HIT".equals(ScoreGuardEngine.state("1-0",1,0)),"1-0 hit");
  expect("BROKEN".equals(ScoreGuardEngine.state("1-0",2,0)),"2-0 breaks 1-0");
  expect("BROKEN".equals(ScoreGuardEngine.state("1-0",1,1)),"either side can break exact score");
  expect("PENDING".equals(ScoreGuardEngine.state("1-0",0,0)),"pending is not broken");
  expect("BROKEN".equals(ScoreGuardEngine.state("0-0",1,0)),"0-0 breaks with first goal");
  JSONArray bets=new JSONArray().put(b("1-0")).put(b("0-0")).put(b("0-1"));
  JSONArray alternative=new JSONArray().put(b("1-0").put("stake",5000).put("offer",3200))
      .put(b("0-0").put("stake",1000).put("offer",100));
  JSONArray alternativeQuote=new JSONArray().put(b("1-0").put("stake",5000).put("offer",4500))
      .put(b("0-0").put("stake",1000).put("offer",200));
  expect(ScoreGuardEngine.selectionSignature(alternative).equals(ScoreGuardEngine.selectionSignature(alternativeQuote)),
      "changing settlement amounts cannot reset AI score analysis");
  expect(!ScoreGuardEngine.selectionSignature(alternative).equals(ScoreGuardEngine.selectionSignature(bets)),
      "switching two tickets to three updates the guard signature");
  expect(!ScoreGuardEngine.selectionSignature(alternative).equals(ScoreGuardEngine.selectionSignature(
      new JSONArray().put(b("1-0").put("closed",true)).put(b("0-0")))), "closing a position affects risk");
  JSONObject atGoal=matches(1,0,bets,t);
  expect(atGoal.optInt("hit")==1 && atGoal.optInt("broken")==2,"portfolio after 1-0 goal");
  expect("UNKNOWN".equals(atGoal.optString("level")),"no stats must never imply safe");
  expect("BROKEN".equals(matches(2,0,bets,t).optString("level")),"2-0 breaks all three");
  JSONObject stats=new JSONObject().put("available",true).put("home",side(6,2,3,.4)).put("away",side(2,0,1,.1));
  JSONObject baseline=live(1,0,t).put("stats",stats);
  expect("BASELINE".equals(ScoreGuardEngine.analyze(baseline,bets,t).optString("level")),"cumulative data alone cannot prove post-goal pressure");
  JSONObject window=new JSONObject().put("minutes",5).put("home",side(3,2,2,.45)).put("away",side(0,0,0,.0));
  baseline.put("goalWarning",new JSONObject().put("five",window));
  expect("HIGH".equals(ScoreGuardEngine.analyze(baseline,bets,t).optString("level")),"new quality shots put hit exact score at risk");
  baseline.put("goalWarning",new JSONObject().put("five",new JSONObject().put("minutes",5).put("home",side(0,0,0,0)).put("away",side(0,0,0,0))));
  expect("LOW".equals(ScoreGuardEngine.analyze(baseline,bets,t).optString("level")),"quiet window only supports low observed threat");
  baseline.put("lastStatsAt",t-100_000);
  expect("UNKNOWN".equals(ScoreGuardEngine.analyze(baseline,bets,t).optString("level")),"stale stats never support safe label");
  JSONArray closed=new JSONArray().put(b("1-0").put("closed",true));
  expect("CLOSED".equals(matches(1,0,closed,t).optString("level")),"manual closure ends watch");
  System.out.println("PASS: "+n+" ScoreGuard Java logic assertions");
 }
}
