package com.htlive.monitor;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.wearable.CapabilityClient;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Post instantly on phone. Let the watch use a native one-screen notification if it ACKs
 * successful local posting, otherwise re-enable the system's normal notification bridging.
 * No NO_BRIDGING manifest flag: uninstalled/offline/permission-denied wearable falls back.
 */
public final class WearAlertRouter {
    private static final String CAPABILITY = "ht_scorepath_watch44";
    private static final long ACK_TIMEOUT_MS = 3500L;
    private static final ConcurrentHashMap<String, Pending> pending = new ConcurrentHashMap<>();
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private WearAlertRouter() {}

    private static class Pending {
        final NotificationManager manager;
        final Notification.Builder builder;
        final int nid;
        Pending(Context context, Notification.Builder b, int id) {
            manager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            builder=b; nid=id;
        }
        void fallback() {
            // Preserve the first phone vibration, do not fire an additional heads-up alert.
            manager.notify(nid, builder.setLocalOnly(false).setOnlyAlertOnce(true).build());
        }
    }

    public static void deliver(Context context, Notification.Builder builder, int nid,
                               JSONObject alert) {
        // Phone notification is immediate, even while the wearable link is being checked.
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(nid, builder.setLocalOnly(true).build());
        String token=UUID.randomUUID().toString();
        Pending state = new Pending(context.getApplicationContext(), builder, nid);
        pending.put(token, state);
        handler.postDelayed(() -> fallback(token), ACK_TIMEOUT_MS);
        try {
            alert.put("token", token);
            byte[] bytes = alert.toString().getBytes(StandardCharsets.UTF_8);
            Wearable.getCapabilityClient(context.getApplicationContext())
                .getCapability(CAPABILITY, CapabilityClient.FILTER_REACHABLE)
                .addOnSuccessListener(info -> {
                    Set<Node> nodes=info.getNodes();
                    if(nodes==null || nodes.isEmpty()) { fallback(token); return; }
                    for(Node node:nodes) {
                        Wearable.getMessageClient(context.getApplicationContext())
                            .sendMessage(node.getId(), "/scorepath/alert", bytes)
                            .addOnFailureListener(e -> {
                                Log.w("HT", "Wear message failed: " + e.getMessage());
                                fallback(token);
                            });
                    }
                    // Task success means queued, not actually displayed; await watch ACK.
                })
                .addOnFailureListener(e -> fallback(token));
        } catch(Exception e) { fallback(token); }
    }

    public static void confirm(String token) {
        if (token != null && !token.isEmpty()) pending.remove(token);
    }

    private static void fallback(String token) {
        Pending p=pending.remove(token);
        if(p!=null) p.fallback();
    }

    /** Best-effort cleanup on the watch; phone notification cancellation remains authoritative. */
    public static void removeFixtures(Context context, Set<String> ids) {
        if (ids==null || ids.isEmpty())return;
        try {
            JSONObject message=new JSONObject();
            org.json.JSONArray list=new org.json.JSONArray();
            for(String id:ids)list.put(id);
            message.put("ids",list);
            byte[] bytes=message.toString().getBytes(StandardCharsets.UTF_8);
            Wearable.getCapabilityClient(context).getCapability(CAPABILITY,CapabilityClient.FILTER_REACHABLE)
                .addOnSuccessListener(info -> {
                    for(Node node:info.getNodes())
                        Wearable.getMessageClient(context).sendMessage(node.getId(),"/scorepath/remove",bytes);
                });
        } catch(Exception e) { Log.w("HT", "Wear cleanup unavailable", e); }
    }
}
