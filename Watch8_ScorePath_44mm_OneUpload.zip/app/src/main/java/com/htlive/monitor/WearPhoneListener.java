package com.htlive.monitor;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;
import android.content.Intent;
import java.nio.charset.StandardCharsets;

/** Phone receiver: native watch confirms posting; optional watch acknowledgement stops repeats. */
public final class WearPhoneListener extends WearableListenerService {
    @Override public void onMessageReceived(MessageEvent event) {
        String path = event.getPath();
        String data = new String(event.getData(), StandardCharsets.UTF_8);
        if ("/scorepath/received".equals(path)) {
            WearAlertRouter.confirm(data);
        } else if ("/scorepath/ack".equals(path) && data.matches("[0-9]{1,12}")) {
            Intent ack = new Intent(this, GuardActionReceiver.class);
            ack.setAction("GUARD_ACK").putExtra("id", data);
            sendBroadcast(ack);
        }
    }
}
