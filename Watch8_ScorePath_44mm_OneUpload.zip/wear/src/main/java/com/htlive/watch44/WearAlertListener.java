package com.htlive.watch44;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;
import org.json.JSONObject;
import org.json.JSONArray;
import java.nio.charset.StandardCharsets;

/** Local notifications open a watch Activity, not the phone detail view. */
public final class WearAlertListener extends WearableListenerService {
    static final String RISK="ht_44_risk_v1";
    static final String TIME="ht_44_time_v1";
    static final String PREF="watch44_alerts";

    @Override public void onMessageReceived(MessageEvent e) {
        try {
            String path=e.getPath();
            if ("/scorepath/remove".equals(path)) { remove(new JSONObject(new String(e.getData(),StandardCharsets.UTF_8))); return; }
            if (!"/scorepath/alert".equals(path))return;
            JSONObject j=new JSONObject(new String(e.getData(),StandardCharsets.UTF_8));
            int nid=j.optInt("nid",-1);
            long at=j.optLong("time",0);
            if(nid<0 || !j.has("fixture") || at<=0 ||
                Math.abs(System.currentTimeMillis()-at)>120_000L)return;
            // Android 13+ denies notifications until the watch owner explicitly grants access.
            if(Build.VERSION.SDK_INT>=33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return;
            ensureChannels();
            SharedPreferences pref=getSharedPreferences(PREF,Context.MODE_PRIVATE);
            String previous=pref.getString("token_"+nid,"");
            String token=j.optString("token","");
            if (!token.isEmpty() && token.equals(previous)) { received(e,token); return; }
            Intent open=new Intent(this,WearAlertActivity.class);
            open.setAction("scorepath_open_"+nid);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            open.putExtra("nid",nid);
            PendingIntent pi=PendingIntent.getActivity(this,nid,open,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            boolean timed=j.optBoolean("timed",false);
            Notification n=new Notification.Builder(this,timed?TIME:RISK)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(j.optString("kind", "比分预警")+" "+j.optString("score","?-?"))
                .setContentText(j.optString("line1", "赛况待核对"))
                .setPriority(Notification.PRIORITY_HIGH)
                .setCategory(timed?Notification.CATEGORY_REMINDER:Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setContentIntent(pi).setAutoCancel(true).setOngoing(false)
                .setOnlyAlertOnce(!j.optBoolean("fresh",true)).setShowWhen(false)
                .build();
            getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString("alert_"+nid,j.toString())
                .putString("token_"+nid,token)
                .putInt("latest",nid).apply();
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(nid,n);
            received(e,token); // ACK only after native notification was actually posted.
        } catch(Exception ex) { Log.e("HT44","Cannot show watch alert",ex); }
    }

    private void received(MessageEvent event,String token){
        if(token==null || token.isEmpty())return;
        Wearable.getMessageClient(this).sendMessage(event.getSourceNodeId(),
            "/scorepath/received",token.getBytes(StandardCharsets.UTF_8));
    }
    private void ensureChannels() {
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel risk=new NotificationChannel(RISK,"重要比分与守分预警",NotificationManager.IMPORTANCE_HIGH);
        risk.enableVibration(true);
        risk.setVibrationPattern(new long[]{0,220,120,220});
        NotificationChannel checkpoint=new NotificationChannel(TIME,"开赛与15/30/40分钟",NotificationManager.IMPORTANCE_HIGH);
        checkpoint.enableVibration(true);
        checkpoint.setVibrationPattern(new long[]{0,170});
        nm.createNotificationChannel(risk);nm.createNotificationChannel(checkpoint);
    }
    private void remove(JSONObject j) {
        JSONArray ids=j.optJSONArray("ids");if(ids==null)return;
        SharedPreferences pref=getSharedPreferences(PREF,Context.MODE_PRIVATE);
        SharedPreferences.Editor edit=pref.edit();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        for(String key:pref.getAll().keySet()) {
            if(!key.startsWith("alert_"))continue;
            try {
                JSONObject notice=new JSONObject(pref.getString(key,"{}"));
                for(int i=0;i<ids.length();i++)if(ids.optString(i).equals(notice.optString("fixture"))) {
                    int nid=notice.optInt("nid",-1);
                    if(nid>=0){nm.cancel(nid);edit.remove("alert_"+nid).remove("token_"+nid);}
                    break;
                }
            }catch(Exception ignored){}
        }
        edit.apply();
    }
}
