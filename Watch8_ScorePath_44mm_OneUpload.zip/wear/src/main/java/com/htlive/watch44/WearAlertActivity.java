package com.htlive.watch44;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.TextUtils;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/** Single, deliberately non-scrollable page for Galaxy Watch8 44 mm (480x480 px). */
public final class WearAlertActivity extends Activity {
    private int dp(float value) {return (int)(getResources().getDisplayMetrics().density*value+.5f);}
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        render(getIntent());
        requestNotifyPermission();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); render(intent);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] perms,int[] results) {
        super.onRequestPermissionsResult(requestCode,perms,results);
        if(requestCode==30) render(getIntent());
    }
    private void requestNotifyPermission() {
        if (Build.VERSION.SDK_INT>=33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);
    }
    private TextView line(String s,int sp,int color,boolean strong) {
        TextView v=new TextView(this);
        v.setText(s==null?"":s); v.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);
        v.setTextColor(color); v.setGravity(Gravity.CENTER);
        v.setSingleLine(true); v.setEllipsize(TextUtils.TruncateAt.END);
        if(strong)v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        // Large user accessibility font settings cannot force a second/scrolling page.
        v.setAutoSizeTextTypeUniformWithConfiguration(Math.max(10,sp-3),sp,1,TypedValue.COMPLEX_UNIT_SP);
        return v;
    }
    private void add(LinearLayout col, View view,int heightDp,int marginBottomDp) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(heightDp));
        p.bottomMargin=dp(marginBottomDp);
        col.addView(view,p);
    }
    private static String flat(String s) {
        return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();
    }
    private void render(Intent intent) {
        SharedPreferences pref=getSharedPreferences(WearAlertListener.PREF,Context.MODE_PRIVATE);
        int nid=intent==null?-1:intent.getIntExtra("nid",-1);
        if(nid<0)nid=pref.getInt("latest",-1);
        JSONObject data=null;
        try {String raw=pref.getString("alert_"+nid,null); if(raw!=null)data=new JSONObject(raw);}
        catch(Exception ignored) {}
        boolean timed=data!=null && data.optBoolean("timed");
        String kind=data==null?"HT WATCH 8":flat(data.optString("kind","比分预警"));
        String score=data==null?"等待赛况":flat(data.optString("score","?-?"));
        String l1=data==null?"从手机接收预警通知":flat(data.optString("line1","赛况待核实"));
        String l2=data==null?"手机端需启动监控":flat(data.optString("line2",""));
        String l3=data==null?"首次安装请允许通知":flat(data.optString("line3",""));
        String fixture=data==null?"":data.optString("fixture","");
        String level=data==null?"":data.optString("level","");
        int accent=timed?0xff55e2d4:("BROKEN".equals(level)?0xffff6d6d:
            "HIGH".equals(level)?0xffffb454:0xfff4da7a);
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        int width=getResources().getDisplayMetrics().widthPixels;
        int height=getResources().getDisplayMetrics().heightPixels;
        // 79% safe circular width; never place long texts at 480px screen corners.
        int contentWidth=(int)(Math.min(width,height)*.79);
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER); col.setPadding(dp(2),dp(2),dp(2),dp(2));
        FrameLayout.LayoutParams position=new FrameLayout.LayoutParams(contentWidth,-2,Gravity.CENTER);
        root.addView(col,position);
        // Fit even if the OS changes logical density or font scale for readability.
        float maxDp=Math.min(width,height)/getResources().getDisplayMetrics().density;
        float scale=Math.min(1f,maxDp/240f);
        col.setScaleX(scale);col.setScaleY(scale);
        add(col,line(kind,15,accent,true),22,1);
        add(col,line(score,36,Color.WHITE,true),48,3);
        add(col,line(l1,14,0xfff0f5f7,true),21,2);
        add(col,line(l2,13,0xffc5d1db,false),21,2);
        add(col,line(l3,13,accent,false),23,3);
        TextView footer=line(timed?"定点复核 · 非自动结算":"重要风险 · 请人工核实",10,0xff85949d,false);
        add(col,footer,15,0);
        if(data!=null && !timed && fixture.matches("[0-9]{1,12}")){
            TextView ack=line("已查看 · 停止重复",11,Color.WHITE,true);
            GradientDrawable bg=new GradientDrawable();
            bg.setColor(0xff26333d);bg.setCornerRadius(dp(20));
            ack.setBackground(bg);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(29));
            p.topMargin=dp(5);p.leftMargin=dp(26);p.rightMargin=dp(26);
            col.addView(ack,p);
            final String id=fixture;
            ack.setOnClickListener(v -> {
                ack.setText("正在发送确认…");
                Wearable.getNodeClient(this).getConnectedNodes().addOnSuccessListener(nodes -> {
                    if(nodes==null||nodes.isEmpty()){ack.setText("手机未连接");return;}
                    final boolean[] delivered={false};
                    for(Node node:nodes){
                        Wearable.getMessageClient(this).sendMessage(node.getId(),"/scorepath/ack",
                            id.getBytes(StandardCharsets.UTF_8))
                            .addOnSuccessListener(unused->{delivered[0]=true;ack.setText("确认已发送");})
                            .addOnFailureListener(e->{if(!delivered[0])ack.setText("发送失败 · 请重试");});
                    }
                }).addOnFailureListener(e->ack.setText("手机未连接"));
            });
        }
        setContentView(root);
    }
}
