# Galaxy Watch 8 44mm 专用 — HT ScorePath Guard 双端预警 v3.1

这是针对 Samsung Galaxy Watch8 **44mm / Wear OS 6 / 480 × 480 圆屏**制作的**手机＋手表双 APK 工程**。

> 已完成源码与本地算法测试，未做真机及 Android SDK 编译。此文件不能直接安装：需要先在 GitHub Actions 构建两个 APK。

## 核心结构

| 模块 | 安装位置 | 功能 |
|---|---|---|
| `app` | 手机 | 完整保留原 HT ScorePath Guard 用户界面、API、比赛监控、2/3 张单、AI/OCR、手动结算复核和 0/15/30/40 分钟提醒逻辑；新增向手表发送一屏预警 |
| `wear` | Galaxy Watch8 44mm | 接收手机数据 → 本地通知 → 点击通知后打开固定无滚动的一屏详情，显示比分/分钟/状态/复核动作；重要风险允许“已查看”发送给手机 |

新手机/手表的**同一应用包名** `com.htlive.monitor.scorepathguard.watch8`，由同一个工作流、同一 debug 密钥签名，才可以通过 Wear OS Data Layer 配对通信。独立于原版 `com.htlive.monitor.scorepathguard`，不会覆盖原版。此前若安装过 `HT Watch8 预警` 旧独立版但签名不同，可能需要卸载旧独立版后安装（会清空该独立版设置，不影响原版）。

## Watch8 44mm 一屏布局

- 第一行：预警类型（守分风险、红牌、进球、比分命中、开赛或 15/30/40 分钟复核）
- 第二行：**超大比分**（示例 1–0）
- 第三行：**实际比赛分钟＋双方球队**（过长球队名自动截断）
- 第四行：**命中/待达/失效**或可用射正/缺失统计提示
- 第五行：**具体人工复核动作**，底部标注非自动结算
- 风险提醒另有“已查看 · 停止重复”按钮；时间提醒不放多余按钮

全部采用纯黑背景、居中安全圆形区域、固定行数和自动缩小单行文字；**原生 Activity 没有 ScrollView，因此点击通知进入的详情页无需翻页**。系统通知列表本身仍由 One UI Watch 绘制，可能滚动；过长球队名/文字被省略号截断，这与“保留所有文字且不翻页”不能同时保证。

## Wear OS 通知通信与避免重复

1. 手机照常产生高优先级通知，手机端立刻显示，并尝试查找具有 `ht_scorepath_watch44` 能力的手表 App。
2. 手表端已安装、连通且具有通知权限时，接收短数据，本地发布**可直接打开手表 Activity 的通知**，然后回发接收确认。
3. 手机收到确认后维持仅手机本地的通知，尽可能避免同一消息在手表上出现系统桥接和原生两次。
4. 若未找到手表 App、消息失败、权限未授权或 3.5 秒内未收到确认，手机重新允许系统**默认桥接**该通知作为回退。系统/网络可能造成延迟或极端重复；不能保证任何离线情况下通知即时送达。
5. 手机端两类渠道、手表端两类渠道独立：风险双振动、定点单振动；手表点击风险详情可以向手机发回已查看，停止相应风险的重复提醒。手表只负责显示，不读取赛事 API、不需要额外联网调用额度。

**不要同时打开原版和新独立版监控同一场比赛**，否则来自两个独立监控的提醒会重复；仅新版本内部做防双端重复。

## GitHub 一次编译两个 APK

1. 打开 <https://github.com/new>，建一个空的 Private 仓库，例如 `HTScorePath-Watch8-44mm`。
2. 在仓库根目录上传文件 **`Watch8_ScorePath_44mm_OneUpload.zip`**（不要改名，不用解压）。
3. 创建 `.github/workflows/build-apk.yml`，粘贴随附 **`Watch8_ScorePath_44mm_build-apk.yml`** 的完整内容。
4. 打开 **Actions → Build Watch8 44mm Phone and Wear APKs → Run workflow**。
5. 下载两份 Artifacts，分别解压得到：
   - `HT-Watch8-44mm-PHONE-APK` → `app-debug.apk`（安装手机）
   - `HT-Watch8-44mm-WEAR-APK` → `wear-debug.apk`（安装 Galaxy Watch 8 44mm）
6. 手表端先打开一次 `HT 赛况预警` **允许通知权限**；手机端打开 `HT Watch8 预警` 允许通知、设置 API Key 和需要监控的比赛。
7. Galaxy Wearable → 手表设置 → 通知 → 应用通知，确认此应用允许显示；在手表上允许两条本地通知渠道；退出免打扰等会挡住提醒的模式。
8. 手机 App 的“模拟进球预警”可用于现场测试。此测试只用于验证通知链路，不是真实比赛预警。

**注意：两端 APK 必须由同一 Actions 构建步骤生成；不要把旧 repo 里下载的手机 APK 与新 repo 的手表 APK 混装，签名可能不同。**

## 测试、原版保留及风险

- 本地 Java/Node 算法测试通过，包括 2/3 张比分单、0/15/30/40 分钟、守分/进球/VAR、44mm 字段组合。
- 比对确认原版手机 `index.html`、`MainActivity.java`、`MonitorService.java`、`ReminderReceiver.java` 和核心风险算法文件未修改，原版逻辑保持不变。
- 手表无自动下注、无自动提前结算；数据缺失、旧统计、比赛延迟需人工复核，通知并非实时赔率保证。
- 本地环境没有 Android SDK/Gradle，**APK 实际编译、蓝牙/Wear OS 数据层连接、手表一屏排版与通知桥接回退还需要真机测试**。
- Android/Wear OS 通知受用户权限、免打扰、节电策略、手表佩戴、手机网络和后台限制影响。

基础工程的原逻辑说明见 `docs/HT_ScorePath_v3_原版逻辑说明.md`。

官方开发资料：
- <https://developer.android.com/training/wearables/notifications>
- <https://developer.android.com/training/wearables/notifications/bridger>
- <https://developer.android.com/training/wearables/data/events>
- <https://developers.google.com/android/reference/com/google/android/gms/wearable/MessageClient>
