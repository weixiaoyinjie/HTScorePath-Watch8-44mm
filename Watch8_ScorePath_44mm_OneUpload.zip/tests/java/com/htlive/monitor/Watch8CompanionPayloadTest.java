package com.htlive.monitor;
import org.json.JSONObject;
import org.json.JSONArray;
public final class Watch8CompanionPayloadTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        JSONObject m=new JSONObject().put("home","曼彻斯特联队").put("away","切尔西")
            .put("h","1").put("a","0").put("minute",36)
            .put("guardRisk",new JSONObject().put("level","HIGH")
                .put("items",new JSONArray().put(new JSONObject()))
                .put("hit",1).put("pending",1).put("broken",0));
        JSONObject risk=Watch8CompanionPayload.create("101",230,"🛡 守分风险",m,System.currentTimeMillis(),"",true);
        check("101".equals(risk.optString("fixture")),"fixture lost");
        check("1-0".equals(risk.optString("score")),"score wrong");
        check(risk.optString("line1").contains("36'"),"live minute missing");
        check(risk.optString("line2").contains("命中1"),"risk states missing");
        check(risk.optString("line3").contains("高风险"),"action missing");
        check(!risk.optBoolean("timed"),"risk misclassified");
        JSONObject timed=Watch8CompanionPayload.create("101",231,"第15分钟定点复核",m,System.currentTimeMillis(),"",true);
        check(timed.optBoolean("timed"),"checkpoint misclassified");
        check(timed.optString("kind").contains("15'"),"planned mark lost");
        check(timed.optString("line1").contains("36'"),"real minute missing");
        check(timed.optString("line2").contains("统计缺失或滞后"),"stale warning omitted");
        JSONObject empty=Watch8CompanionPayload.create("7",232,"⚽ 进球",null,System.currentTimeMillis(),"",true);
        check("?-?".equals(empty.optString("score")),"unavailable score invented");
        check(!empty.optString("line2").equals(empty.optString("line3")),"duplicate lines");
        System.out.println("44mm companion payload tests OK");
    }
}
